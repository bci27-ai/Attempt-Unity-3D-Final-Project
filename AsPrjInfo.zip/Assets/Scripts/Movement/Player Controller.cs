using UnityEngine;
using UnityEngine.InputSystem;

//https://youtu.be/ZSP3bFaZm-o

public class PlayerController : MonoBehaviour
{
    public PlayerControls playerController;
    private Rigidbody rb;

    private float jumpHeight = 5f;
    private float walkSpeed = 10f;
    //private float sprintSpeed = 15f;

    private void Awake()
    {
        playerController = new PlayerControls();
        playerController.Enable();
        Debug.Log("Input System Enabled in Awake");
    }

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Debug.Log("PlayerController Start()");
        //playerController = new PlayerControls();
        rb = GetComponent<Rigidbody>();
        // Prevent the spin of death
        //rb.constraints = RigidBodyConstraints.FreezeRotationX,RigidBodyConstraints.FreezeRotationZ, RigidbodyConstraints.FreezeRotationY;
        rb.freezeRotation = true;
        // freezes ALL Rotation on capsule.
    }
    //playerController.Disable();

    // wish i had saved the original script... now im trying to fix this again... id know it works for sure at least.
    private void OnJump()
    {
        Debug.Log("Jump");
        rb.AddForce(Vector3.up * jumpHeight, ForceMode.Impulse);
    }

    private void OnMove(InputValue inputValue)
    {
        Debug.Log("Player OnMove() ");
        rb.linearVelocity = inputValue.Get<Vector3>() * walkSpeed;
    }
    /*

    private void OnLook(InputValue inputValue)
    {

        Debug.Log("On look in ply contr");

    }

    private void OnZoom(InputValue inputValue)
    {
        Debug.Log("OnZoom in plyr Contr");

    }
    */




}



/* 
Vector2 input = inputValue.Get<Vector2>();
        // Fix: Map Input Y to 3D Z (Forward) and apply relative to the player's facing direction
        Vector3 moveDirection = transform.right * input.x + transform.forward * input.y;
        
        // Preserve current vertical velocity (gravity) so we don't snap to y=0
        rb.linearVelocity = new Vector3(moveDirection.x * walkSpeed, rb.linearVelocity.y, moveDirection.z * walkSpeed);
*/