/*using UnityEngine;


public class Enemy : MonoBehaviour
{

    public float speed = 3f;
    public float maxHealth = 100f;
    private float currentHealth;

    public HealthBar healthBar; // ref to HealthBar script
    private Transform playerTransform;




    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }


    private void spawnEnemy()
    {
        Debug.Log("Spawn the enemy");
        // Spawn the enemy
            

        // number of enemies

        //Enemy health

        // weapon randomizer? 
    }

    private healthEnemy( float damage, int shielding)
    {
        // max hp
        currentHealth = maxHealth; // Will be determined by 

        //enemyCurrentHp -= 25f;

        // current hp

        // update

        if ("Enemy".healthBar == 0)
        {
            Debug.Log("Enemy Destroyed");
            // possibly use this to show up on screen stats?

            Destroy(GameObject);
        }

    }

    private void enemyUpdate()
    {
        // something other than hp to update on / about enemy


    }


    // Update is called once per frame
    void Update()
    {
        // currenty using player transform until everything works properly, then update

        if (playerTransform != null)
        {
            // This should move toward the player
            Vector3 direction = (playerTransform.position - transform.position).normalized;
            direction.y = 0; // Keep the enemy on the ground
            transform.position += direction * speed * Time.deltaTime;

            // Hopefully faces the player. not sure how to set in insp
            transform.LookAt(new Vector3(playerTransform.position.x, transform.position.y, playerTransform.position.z));
        }

    }
}*/
