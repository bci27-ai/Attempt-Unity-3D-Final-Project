using UnityEngine;
using UnityEngine.InputSystem;
// inputs for keyboard
// gun script just creates an instance of a projectile.
public class Gun : MonoBehaviour
{
    public Transform ProjectileSpawn;
    public GameObject ProjectilePrefab;
    public float ProjectileSpeed = 20f;// make sure the f is there just in case of some bug

    private void Update()
    {
        if (Mouse.current.leftButton.wasPressedThisFrame)  
        {
            Debug.Log("Left Mouse Pressed"); // this works


            var projectileInstance = Instantiate(ProjectilePrefab, ProjectileSpawn.position, ProjectileSpawn.rotation);
            projectileInstance.GetComponent<Rigidbody>().linearVelocity = ProjectileSpawn.forward * ProjectileSpeed;
        }   
    }

    // for press and hold add update, for exmple player wants to use a machine gun or smt



}


// player target cross
//https://youtu.be/gilGaBOq2Ws - mde 2 imagaes deformed knobs, 1*150 150*1 to get +.
//
//looks great... good enough. future add crosshair only appears when player is holding a weapon


//in update:
//(Input.GetKeyDown(KeyCode.Space)) this is legacy

// changed top left scene view above tools from global to local. projectiles now go towards the z axis,
// (blue arrow) AND rotation the spawn point is possible.

// .GetComponent<Rigidbody>().veocity has been deprecated. don't use
