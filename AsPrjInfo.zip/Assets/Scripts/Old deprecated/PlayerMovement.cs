/*using UnityEngine;
using UnityEngine.InputSystem;


public class PlayerMovement : MonoBehaviour
{
    private float speed = 6f;// changeable later.
    private float jump = 5f; // split speed into walk and run itsel
    public float gravity = -9.81f;
    private float rotation = 1f;

    private Transform camTransform;
    GameObject gameObject;

    //private CharacterController player;
    private Vector3 velocity;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {






        rb = GetComponent<Rigidbody>();
        rb.constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;
        // instead of inspector. auto set







        camTransform = Camera.main.transform;

    }
    // https://youtu.be/nR5P7AH4aHE
    // Update is called once per frame

    // as a note, the movement is in relation to the camera, and the cam is connected to the player...
    //https://youtu.be/3GKzUzfEJPI

    private moveInput(PlayerInput input)
    {
        moveInput.y = Keyboard.current.dKey.ReadValue() - Keyboard.current.aKey.ReadValue();
        moveInput.x = Keyboard.current.wKey.ReadValue() - Keyboard.current.sKey.ReadValue();

    }


    private void MovePlayer()
    {
        Vector3 forward = camTransform.forward;
        Vector3 right = camTransform.right;

        forward.y = 0; // stop spin
        right.y = 0;

        forward.Normalize();
        right.Normalize();// prevent faster speed if 2 keys are pressed

        Vector3 moveDirection = (forward * moveInput.y + right * moveInput.x).normalized;

        rb.linearVelocity = new Vector3(moveDirection.x * speed, rb.linearVelocity.y, moveDirection.z * speed);

    }


    private void FixedUpdate()
    {
        MovePlayer();

    }



}

*/



//############################################################
    /*

    void Update()
    {

        float moveHorizontal = 0f;
        float moveVertical = 0f;

        if (Mouse.current != null) // changed from keyboard to mouse
                                   // - cam follows mouse, and determines movement
        {
            //  1 if D , -1 if A , 0 if both or neither are pressed etc
            moveHorizontal = Keyboard.current.dKey.ReadValue() - Keyboard.current.aKey.ReadValue();
            moveVertical = Keyboard.current.wKey.ReadValue() - Keyboard.current.sKey.ReadValue();
        }// future - change the key assignments to be soft. 

        Vector3 move = (transform.right * moveHorizontal + transform.forward * moveVertical).normalized;// normalized means player doens't move faster with w and d etc
        player.Move(move * speed * Time.deltaTime);


        move.y = 0; // stops up and down if player is tilted

        //normalized movement- diag is the same speed as FB LR
        player.Move(move.normalized * speed * Time.deltaTime);

        //Vector3 move = transform.right * Input.GetAxis("Horizontal") + transform.forward * Input.GetAxis("Vertical");
        //player.Move(move * speed * Time.deltaTime);

        // multiply by time delta to ensure player movement stays the same regardless of FPS



        if (player.isGrounded && velocity.y > 0)
        {
            velocity.y = -2f;
            Debug.Log("Player Jump");
        }


        if (Keyboard.current.spaceKey.wasPressedThisFrame && player.isGrounded)
        {
            velocity.y = Mathf.Sqrt(jump * -2f * gravity);
            Debug.Log("isGrounded");

            // Logic so the player can't air jump
            // the video uses the old input system, i fixed it so it uses the new. KB current line is new
        }
    }

        /*
        if (Input.GetButtonDown("Jump") && player.isGrounded)
        {
            velocity.y = Mathf.Sqrt(jump * -2f * gravity);

            Debug.Log("isGrounded");
            // Logic so the player can't air jump
        }


        velocity.y += gravity * Time.deltaTime;
        player.Move(velocity * Time.deltaTime);
        
        */
    




// My version before tutorial

/*
// probably need to update the player's location every time there is a button press. so i guess add a checker here
        while (Keyboard.current.wKey.wasPressedThisFrame)
        {    
            Debug.Log("w key pressed");
            // forward movement
            //Vector3 = ()

        }

        if (Keyboard.current.aKey.wasPressedThisFrame)
        {
            Debug.Log("a key pressed");
            // basic left movement

        }

        if (Keyboard.current.sKey.wasPressedThisFrame)
        {
            Debug.Log("s key was pressed");
            // movemetn reverse

        }

        if (Keyboard.current.dKey.wasPressedThisFrame)
        {
            Debug.Log("d key was pressed");
            // move right
            
        }

        if (Keyboard.current.spaceKey.wasPressedThisFrame)
        { 
            // future jump. LEAVE FOR PROJCETILE SHOOTING FOR NOW
            
        }

        if (Keyboard.current.shiftKey.wasPressedThisFrame)
        {
            Debug.Log(" shift key was pressed");

            // add crouch maybe? and lay down? add counter for fully laying down on sec press? then reset? 
            // no way charachter will in less then 2 weeks
        
        }
 */


     
