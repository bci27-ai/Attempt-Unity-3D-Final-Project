using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UIElements;


[System.Serializable]// all priv vars are available
public class MyPlayMovement : MonoBehaviour
{

    // use rigid body moves to move player with wasd and space
    // 
    private float movementSpeed = 10f;
    //private float jumpHeight = 5f;
    private bool isGrounded = true;

    // location controls

    //private float horizLocation = 
    //private float vLocation = 0f;



    // need to make realtive to the camera direction. lock?
    //private float up = transform.position += Vector3.up * Time.deltaTime;// (0,1,0)
    //private float leftRight = transform.position.z;
    //private float forwardBack = transform.position.x;


    public void Start()
    {
        Rigidbody rb = gameObject.AddComponent<Rigidbody>();
       
        Debug.Log("add rigidbody to gameobject to which the script is attached.");
    }

    // public void MovePosition(Vector3 position)

    public void MovePosition( )
    {
        if (isGrounded == true && Keyboard.current.spaceKey.wasPressedThisFrame)
        {
            // take input for jumping
            transform.position += (Vector3.up * movementSpeed) * Time.deltaTime;
            isGrounded = false;
            Debug.Log("Jump");
        }

        if (isGrounded == true && Keyboard.current.wKey.wasPressedThisFrame)
        {
            //W key, forward
            transform.position += (Vector3.forward * movementSpeed) * Time.deltaTime;
            Debug.Log("Forward");
        }

        if (isGrounded == true && Keyboard.current.sKey.wasPressedThisFrame)
        {
            // s key backward
            transform.position += (Vector3.back * movementSpeed) * Time.deltaTime;
            Debug.Log("Backward Movement");
        }

        if (isGrounded == true && Keyboard.current.aKey.wasPressedThisFrame)
        {
            // a key left
            transform.position += (Vector3.left * movementSpeed) * Time.deltaTime;
            Debug.Log("Left Movement");
        }

        if (isGrounded == true && Keyboard.current.dKey.wasPressedThisFrame)
        {
            // d key right
            transform.position += (Vector3.right * movementSpeed) * Time.deltaTime;
            Debug.Log("Right Movement");
        }

    }

    void FixedUpdate()
    {
        MovePosition();
        //Debug.Log("Fixed update Updated");

        

    }
}


// this is old style, will replace Keyboard.current.wkey etc with keyboard asset
/*
    if (isGrounded == true && Keyboard.current.wKey.wasPressedThisFrame)
        {
            //W key, forward
            transform.position += (Vector3.forward * movementSpeed) * Time.deltaTime;
            Debug.Log("Forward");
        }
 */