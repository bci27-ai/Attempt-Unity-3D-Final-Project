using UnityEngine;

public class Projectile : MonoBehaviour
{
    public GameObject ProjectilePrefab;

    public float life = 2f;
    public float damage = 2f;
    //public float projectileTimeout = 5f;
    public float ProjectileSpeed = 20f;// make sure the f is there just in case of some bug

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Environment"))
        {
            Debug.Log("Environment Collision");
            Destroy(gameObject);
        }

        if (other.CompareTag("Projectile"))
        {
            Debug.Log("Check for Projectile tag and don't destroy after collision");
            //Destroy(gameObject);
        }

        if (other.CompareTag("Player"))
        {
            // this is a call to the PlayerStats script to update the health of the player who got hit by this projectile.
            // this call tells the player stats to update health.
            PlayerStats stats = other.GetComponent<PlayerStats>();

            Destroy(gameObject);
            Debug.Log("Projectile hit player");
        }
    }

    //maybe add projectile hp,
    //  remove when helth reaches 0? spalsh damage

    
   /* 
        //add to all objects

            //Eventually adding a timeout anywway
            if (other.CompareTag("Environment"))
            {
                Destroy(gameObject, life);

            }*/

    //just going to add the instancing of the projectile here, and then add as a child of the gun


}