using UnityEngine;
using System.Collections;
using System.Collections.Generic;


public class PlayerBehavior : MonoBehaviour
{
    public float mSpeed = 10f;
    public float rotateSpeed = 175f;

    private float _vInput;
    private float _hInput;

    private Rigidbody _rb;


    public float jumpVel = 5f;
    private bool _isJumping;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        _rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        _vInput = Input.GetAxis("Vertical") * mSpeed;
        _hInput = Input.GetAxis("Horizontal") * rotateSpeed;

        _isJumping |= Input.GetKeyDown(KeyCode.J);

    }// temporary. rotate is not the way to go. too janky. 

    private void FixedUpdate()
    {
        Vector3 rotation = Vector3.up * _hInput;
        Quaternion angleRot = Quaternion.Euler(rotation * Time.fixedDeltaTime);

        _rb.MovePosition(this.transform.position + this.transform.forward * _vInput * Time.fixedDeltaTime);

        _rb.MoveRotation(_rb.rotation * angleRot);

    }



}
