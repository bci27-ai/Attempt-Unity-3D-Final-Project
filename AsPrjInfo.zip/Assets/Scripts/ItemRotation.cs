using JetBrains.Annotations;
using System.Runtime.CompilerServices;
using UnityEditor;
using UnityEngine;

public class ItemRotation : MonoBehaviour
{

    public int RotationSpeed = 100;
    private Transform _itemTransform;
    private HealthBar healthBar;// for health boost etc


    public int t = 10; // stand in for time. 

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        _itemTransform = this.GetComponent<Transform>();

    }

    // Update is called once per frame
    void Update()
    {
        _itemTransform.Rotate(RotationSpeed * Time.deltaTime, 0, 0);

        // spin direction is wrong
    }

    // yes, i know but ill just use this script. rushing...
    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject != null)
        {
            if (other.CompareTag("Player"))
            {
                Debug.Log(" HpCap Destroy");
                Destroy(gameObject);
            }
            // later leave as is
            if(other.CompareTag("Invis Shield"))
            {                          
                // set a material that makes the player invisible. just for now.
                Debug.Log($"Player Invisible for '{t}' seconds");
                Destroy(gameObject);                
            }




        }
    }


}


