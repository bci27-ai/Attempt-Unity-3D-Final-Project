using UnityEngine;
using UnityEngine.InputSystem; 

public class PlayerCam : MonoBehaviour
{
    public float sensitivity = .5f;
    private float xRotation = 180f;

    //public Transform player;
    private Rigidbody rb;

        void Start()
        {
            rb = GetComponentInParent<Rigidbody>();

            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false; 
        // lock and hide the cursor. eventually. probably could be made vis for future crosshair etc
        }
    //
        // add for inventory access
        // private bool ifInventory = false               
    
        
    float currentDistance = 0f;
    //public bool isThirdPerson = false;
    // maybe is 3rd should be a toggle between two camera

    void Update()
    {
        Vector2 mouseDelta = Mouse.current.delta.ReadValue();

        //float mouseX = Input.GetAxis("Mouse X") * sensitivity;
        // for x n y

        float mouseX = mouseDelta.x * sensitivity * 0.1f;
        float mouseY = mouseDelta.y * sensitivity * 0.1f;



        xRotation -= mouseY;
        xRotation = Mathf.Clamp(xRotation, -90f, 90f);

        // make sure the cam can't go more than 180 deg total.


        transform.localRotation = Quaternion.Euler(xRotation, 0f, 0f);  
        
        transform.parent.Rotate(Vector2.up * mouseX);


        // camera zoom to third below
        float scroll = Mouse.current.scroll.ReadValue().y;

        currentDistance = Mathf.Clamp(currentDistance - scroll, 0f, 10f);
        transform.localPosition = new Vector3(0, .7f, -currentDistance);


        //isThirdPerson = true;
        // maybe is 3rd should be a toggle between two cameras

        // scroll function doesn't work properly.�
        // zoom returns back when scroll stops.
    }
}
