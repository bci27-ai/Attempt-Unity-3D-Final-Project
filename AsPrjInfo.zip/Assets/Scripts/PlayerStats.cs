using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Processors;

[System.Serializable]
// makes the entire class serializable without writing to every line.

public class PlayerStats : MonoBehaviour
{

    public float MaxHealth = 100f;
    public float currentHealth;
    private HealthBar healthBar;
    

    //[SerializeField]
    //private bool isDead = false;
    
    public void Start()
    {
        currentHealth = MaxHealth; // Starting health.

        healthBar = FindFirstObjectByType<HealthBar>();
        //change to child bc enemy will use same script
        //
        //****** LATER


        // for auto helath bar connection if its not connected. just for futre speed up     
        
        if (healthBar != null)
        {
            healthBar.MaxHealth = MaxHealth;
            healthBar.SetHealth(currentHealth); // Must be in order for math purpose..? SAFETY add
                                                // makes no sense, this function lets me call it from below...
        }
        //above 2 if fixed object ref null

        //currentHealth = maxHealth;
        //healthBar.SetMaxHealth(MaxHealth);// null ref error
    }

   
    public void SetHealth(float healthChange)
    {
        currentHealth += healthChange;
        currentHealth = Mathf.Clamp(currentHealth, 0, MaxHealth);
        // "clamps" the hp so it can't go below 0

        if (healthBar != null)// just in case
        {
            healthBar.SetHealth(currentHealth);
        }
    }

    //[field: Header("Player Damage")] this is called a header. only works on searlize field. 
    // can also use [Space] with this. creates space in inspector


    #region Player Health Damage
    // This will include all the different things that hurt a players health

    /*
    private void Death()
    {
        if (healthBar == null)
        {
            Destroy(gameObject);// as in th eplayer capsule so th
            Debug.Log("Player Dead");
        }// idealy destoy the player?
    }
    */

    public void OnTriggerEnter(Collider other)
    {
        if (healthBar != null)
        { // implementation for player dead. updates won't work because the healthbar is attached to the player
            // null refers to something, this case "healthBar" being gone., totally unaccesible, (in memory)
            // same difference

            if (other.CompareTag("Projectile"))
            {
                SetHealth(-10f);
                Debug.Log("Player Hit");
            }

            if (other.CompareTag("Enemy"))
            {
                SetHealth(-5f);
                Debug.Log("Bumped into an enemy");
                Debug.Log(-5);
            }
            if (other.CompareTag("HealthBoost"))
            {
                SetHealth(+20f);
                Debug.Log("Player Increased Health");
            }
        }
        // fire - splash raduis, damage over time, use the same timer as invis when implemented. Prob make new scrit:  PlayerEffects

        // damaging potion
        // use Switch Statement or potion type Enum

        // REMARK How can i organize code if there are potions involved, that 1 damge, 2 heal, 3 allow tempoarary flight, 4 distort vision, etc...?
        // potions need a built in decay timer...
    }
    #endregion Player Health Damage

    #region Player Health Increase
    /*
    private void OnTriggerEnter()
    {
        // implement null for hp bar in case of dead player

        Debug.Log("Future Health Increase Region");

    }

    */

    #endregion Player Health Increase





    public void Update( )
    {
       

       
    }


    // error when this was used: can be changed for the project Edit>project settings> player > inputs under C.

    /*if (Input.GetKeyDown("d"))
        {SetHealth(-20f);}
        if (Input.GetKeyDown("u"))
        { SetHealth(20f);}
        */
    /*
    if (Keyboard.current.dKey.wasPressedThisFrame)
    {   SetHealth(-20f);    }
            if (Keyboard.current.eKey.wasPressedThisFrame)
    {            SetHealth(20f);        }
    */




    /*
        //public float halfHpSpeed;
        // add var for movement response? maybe charachter get affected by spell/ hp, etc

        private HealthBar healthBar;
        // Start is called once before the first execution of Update after mono script is created
      
        public void TakeDamage(float damage)
        {
            currentHealth -= damage;
            //healthBar.SetSlider(currentHealth);
            // visual change
            if (healthBar != null)
                healthBar.SetSlider(currentHealth);

            if (currentHealth <= 0)
            {
                Destroy(gameObject );
                Debug.Log("Player is dead");
                // can use $ string for future when implementing more players            
            }
        }
        */

}
