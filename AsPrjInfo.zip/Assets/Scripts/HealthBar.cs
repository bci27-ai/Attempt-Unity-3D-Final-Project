using UnityEngine;
public class HealthBar : MonoBehaviour
{    
    // this is using the built in unity healthbar. It includes the math etc for the actual changes.

    // billboardmeans the healthbar above the player is always facing the camera so the hp is visible
    private Transform mainCameraTransform;

    //hp bar
    public float currentHealth, MaxHealth, Width, Height;

    [SerializeField]
    private RectTransform healthBar;
    public bool isThirdPerson = false;// name deos not exist error now defined.
    
    public void SetHealth(float health)
    {
        currentHealth = health;

        if (MaxHealth > 0 && healthBar != null)
        {
            // current / max) * appearence. bar can go over the max size if the max is hand set to bigger than 100.
            // eventually FIX THIS
            float newWidth = (currentHealth / MaxHealth) * Width;
            healthBar.sizeDelta = new Vector2(newWidth, Height);
        }                
    }
    void Start()
    {
        if (healthBar != null)
        {
            Width = healthBar.sizeDelta.x;
            Height = healthBar.sizeDelta.y;
        }

        SetHealth(MaxHealth);

        //cashe the cam
        //BILLBOARD
        if (Camera.main != null)
        {
            mainCameraTransform = Camera.main.transform;
        }
    }

    // FOR BILLBOARD : face hp bar towards camera always 
    void LateUpdate()
    {
        if (mainCameraTransform != null)
        {// cHECKS TO MAKE SURE THE PLAYER IS DONE MOVING BEFORE STOPPING UPDATES TO THE bILLBOARD
            transform.LookAt(transform.position + mainCameraTransform.rotation * Vector3.forward, mainCameraTransform.rotation * Vector3.up);
        }
    }
}

// adding the canvas was a disaster. after adding canvas select it in the heiarchy and press f when you put your mouse over the scene view. canvas shows up